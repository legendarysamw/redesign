/* Oakville Handyman Sam — minimal interactions: mobile nav, FAQ accordion, quote form → SMS */
(function(){
  "use strict";

  /* mobile nav toggle */
  var toggle = document.getElementById("menu-toggle");
  var nav = document.getElementById("mobile-nav");
  if(toggle && nav){
    toggle.addEventListener("click", function(){
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* FAQ accordion */
  var items = document.querySelectorAll(".faq");
  items.forEach(function(item){
    var q = item.querySelector(".faq-q");
    var a = item.querySelector(".faq-a");
    if(!q || !a) return;
    q.addEventListener("click", function(){
      var isOpen = item.classList.contains("open");
      items.forEach(function(o){ o.classList.remove("open"); o.querySelector(".faq-a").style.maxHeight = null; o.querySelector(".plus").textContent = "+"; });
      if(!isOpen){
        item.classList.add("open");
        a.style.maxHeight = a.scrollHeight + "px";
        item.querySelector(".plus").textContent = "−";
      }
    });
  });

  /* Quote form → pre-filled SMS (no backend / no email on file) */
  var form = document.getElementById("quote-form");
  if(form){
    form.addEventListener("submit", function(e){
      e.preventDefault();
      var v = function(id){ var el = document.getElementById(id); return el ? el.value.trim() : ""; };
      var lines = ["Hi Sam, quote request from your website:"];
      if(v("qf-name")) lines.push("Name: " + v("qf-name"));
      if(v("qf-phone")) lines.push("Phone: " + v("qf-phone"));
      if(v("qf-email")) lines.push("Email: " + v("qf-email"));
      if(v("qf-area")) lines.push("Property area: " + v("qf-area"));
      if(v("qf-service")) lines.push("Service needed: " + v("qf-service"));
      if(v("qf-date")) lines.push("Preferred date: " + v("qf-date"));
      if(v("qf-desc")) lines.push("Job: " + v("qf-desc"));
      var body = encodeURIComponent(lines.join("\n"));
      var ok = document.getElementById("form-ok");
      if(ok) ok.style.display = "block";
      ok && ok.scrollIntoView({behavior:"smooth", block:"center"});
      window.location.href = "sms:+12899811471?&body=" + body;
    });
  }
})();
